import React, { useEffect, useState } from 'react';
import { onAuthStateChanged } from 'firebase/auth';
import { doc, getDoc } from 'firebase/firestore';
import { auth, db } from '../services/firebase'; // assumes you export `db` (Firestore) here
import {
  generateRecipe,
  describeRecipeError,
  type GeneratedRecipe,
} from '../services/recipes';

type FavoriteRecipe = {
  id: string;
  name: string;
  ingredients?: string;
};

/**
 * ASSUMPTION: the profile lives at users/{uid} and has a `favoriteRecipes`
 * field that is an array of either strings or { id?, name, ingredients? }.
 * Adjust this one function to match your real profile shape
 * (or swap it for a helper from ../services/users).
 */
async function fetchFavoriteRecipes(uid: string): Promise<FavoriteRecipe[]> {
  const snap = await getDoc(doc(db, 'users', uid));
  if (!snap.exists()) return [];

  const raw = snap.data().favoriteRecipes;
  if (!Array.isArray(raw)) return [];

  return raw
    .map((item: any, i: number): FavoriteRecipe | null => {
      if (typeof item === 'string') return { id: `${i}-${item}`, name: item };
      if (item && typeof item.name === 'string') {
        return {
          id: String(item.id ?? `${i}-${item.name}`),
          name: item.name,
          ingredients: typeof item.ingredients === 'string' ? item.ingredients : undefined,
        };
      }
      return null;
    })
    .filter((r): r is FavoriteRecipe => r !== null);
}

const Cook: React.FC = () => {
  const [favorites, setFavorites] = useState<FavoriteRecipe[]>([]);
  const [favoritesLoading, setFavoritesLoading] = useState(true);
  const [favoritesError, setFavoritesError] = useState<string | null>(null);
  const [signedIn, setSignedIn] = useState(true);

  const [selectedId, setSelectedId] = useState('');
  const [recipe, setRecipe] = useState<GeneratedRecipe | null>(null);
  const [generating, setGenerating] = useState(false);
  const [genError, setGenError] = useState<string | null>(null);
  const [done, setDone] = useState<Record<number, boolean>>({});

  // Cache so re-selecting a recipe doesn't spend another API call
  const [cache, setCache] = useState<Record<string, GeneratedRecipe>>({});

  // 1. Load favorites from the signed-in user's profile
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      if (!user) {
        setSignedIn(false);
        setFavorites([]);
        setFavoritesLoading(false);
        return;
      }
      setSignedIn(true);
      setFavoritesLoading(true);
      try {
        setFavorites(await fetchFavoriteRecipes(user.uid));
        setFavoritesError(null);
      } catch (err) {
        console.error('Failed to load favorites:', err);
        setFavoritesError('Could not load your favorite recipes.');
      } finally {
        setFavoritesLoading(false);
      }
    });
    return unsubscribe;
  }, []);

  const selected = favorites.find((r) => r.id === selectedId) ?? null;

  // 2. Generate instructions when a recipe is selected
  const load = async (target: FavoriteRecipe, force = false) => {
    setDone({});
    setGenError(null);

    if (!force && cache[target.id]) {
      setRecipe(cache[target.id]);
      return;
    }

    setRecipe(null);
    setGenerating(true);
    try {
      const result = await generateRecipe(target.name, target.ingredients);
      setCache((c) => ({ ...c, [target.id]: result }));
      setRecipe(result);
    } catch (err) {
      console.error('Recipe generation failed:', err);
      setGenError(describeRecipeError(err));
    } finally {
      setGenerating(false);
    }
  };

  useEffect(() => {
    if (!selected) {
      setRecipe(null);
      setGenError(null);
      return;
    }
    load(selected);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedId]);

  return (
    <div style={{ maxWidth: 640, margin: '2rem auto', padding: '1rem' }}>
      <h1>Cook</h1>

      {favoritesLoading && <p>Loading your favorites...</p>}

      {!favoritesLoading && !signedIn && <p>Please log in to see your favorite recipes.</p>}

      {favoritesError && (
        <p role="alert" style={{ color: '#ff6b6b' }}>
          {favoritesError}
        </p>
      )}

      {!favoritesLoading && signedIn && !favoritesError && favorites.length === 0 && (
        <p>You have no favorite recipes yet. Favorite some and come back!</p>
      )}

      {favorites.length > 0 && (
        <>
          <label htmlFor="favorite-recipe">Choose a favorite recipe: </label>
          <select
            id="favorite-recipe"
            value={selectedId}
            onChange={(e) => setSelectedId(e.target.value)}
          >
            <option value="">Select a recipe</option>
            {favorites.map((r) => (
              <option key={r.id} value={r.id}>
                {r.name}
              </option>
            ))}
          </select>
        </>
      )}

      {selected && (
        <div style={{ marginTop: '1.5rem' }}>
          <h2>{selected.name}</h2>

          {generating && <p>Writing your instructions...</p>}

          {genError && (
            <div role="alert">
              <p style={{ color: '#ff6b6b' }}>{genError}</p>
              <button type="button" onClick={() => load(selected, true)}>
                Try again
              </button>
            </div>
          )}

          {recipe && (
            <>
              <p>
                ⏱️ <strong>Prep:</strong> {recipe.prepTime} | <strong>Cook:</strong> {recipe.cookTime}
              </p>

              {selected.ingredients && (
                <>
                  <h3>Ingredients</h3>
                  <p>{selected.ingredients}</p>
                </>
              )}

              <h3>Instructions</h3>
              <ol style={{ paddingLeft: 20, lineHeight: 1.6 }}>
                {recipe.instructions.map((step, i) => (
                  <li
                    key={`${selected.id}-${i}`}
                    style={{
                      marginBottom: 8,
                      textDecoration: done[i] ? 'line-through' : 'none',
                      opacity: done[i] ? 0.6 : 1,
                    }}
                  >
                    <label style={{ cursor: 'pointer' }}>
                      <input
                        type="checkbox"
                        checked={!!done[i]}
                        onChange={() => setDone((d) => ({ ...d, [i]: !d[i] }))}
                        style={{ marginRight: 8 }}
                      />
                      {step}
                    </label>
                  </li>
                ))}
              </ol>

              <button type="button" onClick={() => load(selected, true)}>
                Regenerate
              </button>
            </>
          )}
        </div>
      )}
    </div>
  );
};

export default Cook;